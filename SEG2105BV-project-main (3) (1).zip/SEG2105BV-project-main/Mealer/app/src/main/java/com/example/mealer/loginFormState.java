package com.example.mealer;
import androidx.annotation.Nullable;
public class loginFormState {

}
