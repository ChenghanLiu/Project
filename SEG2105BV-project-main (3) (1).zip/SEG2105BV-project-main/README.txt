SEG2105 Project - Mealer APP
Group Members :
	Lanhui Chen, 300139119
	Arjun Atwal, 300247671
        Chenghan Liu, 300028423
        Mariya Frolova, 300264691
